function show_save() {

    var show_div;

    show_div = document.createElement('div');
    show_div.setAttribute('class' , "message_save");
    show_div.setAttribute('id' , "show_save");

    text_save = document.createTextNode("Load ... ");
    show_div.appendChild(text_save);
    document.body.appendChild(show_div);
}

function remove_block() {
    if(document.getElementById("show_save")) {  // delete block
        document.body.removeChild(document.getElementById("show_save"));
    }
}