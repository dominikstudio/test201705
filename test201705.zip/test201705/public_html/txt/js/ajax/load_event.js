function ajaxLoadEvent(element, path, date)
{
    remove_block();
    show_save();

    JsHttpRequest.query(
    path,
    {
    "date" : date
    },
    function(result) {
        if (result) {
            element.innerHTML = result["value"];

            setTimeout("remove_block()", 1000);
        }
    },
    true
    );

}

function getCalendar(element, path, date)
{
	document.getElementById("event_"+date).style.display = "none";
	document.getElementById("img_event_"+date).style.display = "block";

	JsHttpRequest.query(
	path,
	{
	"date" : date
	},
	function(result) {
		if (result) {
			element.innerHTML = result["value"];
		}
	},
	true
	);
}