function getTop(element) {
    var top = 0;
    while(element) {
        top = top + parseInt(element.offsetTop);
        element = element.offsetParent;
    }

	return top;
}

function getLeft(element) {
    var left = 0;
    while(element) {
        left = left + parseInt(element.offsetLeft);
        element = element.offsetParent;
    }

	return left;
}