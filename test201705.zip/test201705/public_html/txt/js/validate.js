function validate(element)
{
    if(!confirm('Ви дійсно бажаєте видалити ?')) {
        return false;
    }else {
        return  true;
    }
}