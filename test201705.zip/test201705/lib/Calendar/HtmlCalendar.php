<?php
class Html_Calendar
{
    private $db;
	private $base_dir;

    function __construct()
    {
        $this->db = $GLOBALS['db'];
		$this->base_dir = $GLOBALS['config']['base_dir'];
    }

    function calendar($param)
    {
        $res = '';

        if(!empty($param['date']))
            $date = date("Ymd", strtotime($param['date']));
        elseif(!empty($param['2']) && $param['2'] == 'date' && !empty($param['3']))
            $date = date("Ymd", strtotime($param['3']));
        else
            $date = date("Ymd");

        $year  = date("Y", strtotime($date));
        $month = date("m", strtotime($date));
        $month_title = $this->getMonthTitle($date);

        $month_current = mktime(0, 0, 0, $month, 1, $year);
        $month_prev = date("Ymd", strtotime("-1 month", $month_current));
        $month_next = date("Ymd", strtotime("+1 month", $month_current));

        $day_count = date("t", $date);
        $day_counter = 0;
        $week_day = date("w", strtotime("$year-$month-01"));

        while($day_counter < $day_count)
        {
            $res .= "<tr>";

            for($j = 0 ; $j < 7 ; $j++)
            {
                $color_sunday = ($j == 0) ? " color: red; " : "" ;

                if($day_counter == 0)
                {
                    if($j == $week_day)
                    {
                        $day_counter++;
                        $date_calendar = date("Y-m-d", strtotime("$year-$month-$day_counter"));
                        $event_by_date = $this->getEventByDate($date_calendar);
						$events_html = '';

                        if(count($event_by_date) > 0)
						{
							foreach($event_by_date as $event_data)
							{
								$id = intval($event_data['id']);
								$events_html .= '
								    <div id="event' . $id . '"  class="day_event"
									   style="background: ' . htmlspecialchars(stripslashes($event_data['color'])) . '; width: 20px; height: 20px; float: left;"
									   onclick="javascript:ajaxLoadEvent(document.getElementById(\'page_content\'), \'/' . $this->base_dir . 'ajax/event/view/' . $id . '\', null);">
									&nbsp;
									</div>
								';
							}
						}
						
						$res .= "
							<td class='block_calendar_event' style='{$color_sunday}'>
								$day_counter
								<div class='day_events'>{$events_html}&nbsp;</div>
							</td>
						";
                    }
                    else
                        $res .= "<td class='block_calendar'>&nbsp;</td>";
                }
                elseif($day_counter == $day_count)
                {
                    $res .= "<td class='block_calendar'>&nbsp;</td>";
                }
                else
                {
                    $day_counter++;
                    $date_calendar = date("Y-m-d", strtotime("$year-$month-$day_counter"));
                    $event_by_date = $this->getEventByDate($date_calendar);
					$events_html = '';

					if(count($event_by_date) > 0)
					{
						foreach($event_by_date as $event_data)
						{
							$id = intval($event_data['id']);
							$events_html .= '
								<div id="event' . $id . '"  class="day_event"
								   style="background: ' . htmlspecialchars(stripslashes($event_data['color'])) . '; width: 20px; height: 20px; float: left;"
								   onclick="javascript:ajaxLoadEvent(document.getElementById(\'page_content\'), \'/' . $this->base_dir . 'ajax/event/view/' . $id . '\', null);">
								' . $id . '&nbsp;
								</div>
							';
						}
					}
					
					$res .= "
						<td class='block_calendar_event' style='{$color_sunday}'>
							$day_counter
							<div class='day_events'>{$events_html}&nbsp;</div>
						</td>
					";
                }
            }
            $res .= "</tr>";
        }

        $res = "
<table cellspacing='1' cellpadding='1' style='border: 1px solid #aaa;' width='100%'>
    <tr>
        <td class='block_title'>
            <a id='event_{$month_prev}' style='display: block;' href='javascript:getCalendar(document.getElementById(\"page_content\"), \"/{$this->base_dir}ajax/event/\", \"{$month_prev}\");'><<</a>
            <span id='img_event_{$month_prev}' style='display: none; height: 15px; width: 15px; overflow: hidden;'><img src='/{$this->base_dir}files/img/load.gif' style='padding: 0px; height: 15px; width: 15px;'></span>
        </td>
        <td class='block_title' colspan=5>{$month_title}&nbsp; {$year}</td>
        <td class='block_title'>
            <a id='event_{$month_next}' style='display: block;' href='javascript:getCalendar(document.getElementById(\"page_content\"), \"/{$this->base_dir}ajax/event/\", \"{$month_next}\");'>>></a>
            <span id='img_event_{$month_next}' style='display: none;  height: 15px; width: 15px; overflow: hidden;'><img src='/{$this->base_dir}files/img/load.gif' style='padding: 0px; height: 15px; width: 15px;'></span>
        </td>
    </tr>
    {$res}
</table>
        ";

        if(empty($param['ajax']))
        {
            //$res = '<div id="calendar_event">' . $res . '</div>'; 
        }

        return $res;
    }
	
	function calendarEdit($param, $date_input, $name = 'date', $id = '001')
    {
        $res = '';

        if(!empty($param['date']))
            $date = date("Ymd", strtotime($param['date']));
        elseif(!empty($date_input))
            $date = date("Ymd", strtotime($date_input));
        else
            $date = date("Ymd");

        if(!empty($param['ajax']) && !empty($param['id'])) // get id from ajax
            $id = $param['id'];

        if(!empty($date_input))
            $date_input = date("d.m.Y", strtotime($date_input));
        elseif(empty($param['search']))
            $date_input = date("d.m.Y");

        $year  = date("Y", strtotime($date));
        $month = date("m", strtotime($date));
        $month_title = $this->getMonthTitle($date);

        $month_current = mktime(0, 0, 0, $month, 1, $year);
        $month_prev = date("Ymd", strtotime("-1 month", $month_current));
        $month_next = date("Ymd", strtotime("+1 month", $month_current));

        $day_count = date("t", strtotime($date));
        $day_counter = 0;
        $week_day = date("w", strtotime("$year-$month-01"));

        while($day_counter < $day_count)
        {
            $res .= "<tr>";

            for($j = 0 ; $j < 7 ; $j++)
            {
                $color_sunday = ($j == 0) ? " color: red !important; " : "" ;

                if($day_counter == 0)
                {
                    if($j == $week_day)
                    {
                        $day_counter++;
                        $res .= "<td class='block_calendar_edit' onclick=\"setDate('$day_counter.$month.$year', '$id');\"><a href='javascript:void(0);' style='$color_sunday'>$day_counter</a></td>";
                    }
                    else
                        $res .= "<td class='block_calendar_edit'>&nbsp;</td>";
                }
                elseif($day_counter == $day_count)
                {
                    $res .= "<td class='block_calendar_edit'>&nbsp;</td>";
                }
                else
                {
                    $day_counter++;
                    $res .= "<td class='block_calendar_edit' onclick=\"setDate('$day_counter.$month.$year', '$id');\"><a href='javascript:void(0);' style='$color_sunday'>$day_counter</a></td>";
                }
            }
            $res .= "</tr>";
        }

        $res = "
<table cellspacing='1' cellpadding='1' style='border: 1px solid #aaa; background: #eee;' width='200px'>
    <tr>
        <td class='block_title'>
            <a id='event_{$month_prev}_{$id}' style='display: block;' href='javascript:getCalendarEdit(\"{$month_prev}\", \"{$name}\", \"{$id}\");'><<</a>
            <span id='img_event_{$month_prev}_{$id}' style='display: none; height: 15px; width: 15px; overflow: hidden;'><img src='/{$this->base_dir}files/img/load.gif' style='padding: 0px; height: 15px; width: 15px;'></span>
        </td>
        <td class='block_title' colspan=5>{$month_title}&nbsp; {$year}</td>
        <td class='block_title'>
            <a id='event_{$month_next}_{$id}' style='display: block;' href='javascript:getCalendarEdit(\"{$month_next}\", \"{$name}\", \"{$id}\");'>>></a>
            <span id='img_event_{$month_next}_{$id}' style='display: none;  height: 15px; width: 15px; overflow: hidden;'><img src='/{$this->base_dir}files/img/load.gif' style='padding: 0px; height: 15px; width: 15px;'></span>
        </td>
    </tr>
    {$res}
</table>
        ";

        if(empty($param['ajax']))
        {
            $width = (!empty($param['search'])) ? '65' : '90' ;

            $res = '
                <input id="event_date_' . $id . '" onclick="showCalendar(\'' . $id . '\');" onfocus="showCalendar(\'' . $id . '\');" onchange="hideCalendar(\'' . $id . '\');" type="text" name="' . $name . '" value="' . $date_input . '" style="width: ' . $width . 'px; border: 1px solid grey;">
                <span id="calendar_event_' . $id . '" style="position: absolute; display: none; z-index: 2;">' . $res . '</span><br>
            ';

            if(empty($GLOBALS['show_date_js']))
            {
                $GLOBALS['show_date_js'] = 'showed_already';

                $res .= '
                <script type="text/javascript">
                    function getCalendarEdit(month, name, id)
                    {
                        document.getElementById("event_"+month+"_"+id).style.display = "none";
                        document.getElementById("img_event_"+month+"_"+id).style.display = "block";

                        JsHttpRequest.query(
                        "/' . $this->base_dir . '/ajax/event/editcalendar/",
                        {
                        "date" : month,
                        "name" : name,
                        "id"   : id
                        },
                        function(result) {
                            if (result) {
                                document.getElementById("calendar_event_"+id).innerHTML = result["value"];
                            }
                        },
                        true
                        );
                    }
                    function setDate(date, id)
                    {
                        document.getElementById("event_date_"+id).value = date;
                        hideCalendar(id);
                    }
                    function showCalendar(id)
                    {
                        document.getElementById("calendar_event_"+id).style.display = "block";
                    }
                    function hideCalendar(id)
                    {
                        document.getElementById("calendar_event_"+id).style.display = "none";
                    }
                </script>
                ';
            }

        }

        return $res;
    }

    function getMonthTitle($date)
    {
        //$month = date("n", strtotime($date));
        //$month_title = array(1 => 'Січень', 2 => 'Лютий', 3 => 'Березень', 4 => 'Квітень', 5 => 'Травень', 6 => 'Червень', 7 => 'Липень', 8 => 'Серпень', 9 => 'Вересень', 10 => 'Жовтень', 11 => 'Листопад', 12 => 'Грудень' );

        //$res = $month_title[$month];
		
		$res = date("F", strtotime($date));

        return $res;
    }

    function getEventByDate($date)
    {
        $res = array();

        $query = "
SELECT `id`, `color`
FROM `event`

WHERE 1
AND `date` = '$date'
AND `show` = '1'
AND `deleted` = '0'
        ";
        $list_date = $this->db->getRows($query);

        if(empty($list_date))
            $list_date = array();

        //$res['count'] = count($list_date);

        //if($res['count'] == 1)
        //    $res['id'] = $list_date[0]['id'];

        return $list_date;
        //return $res;
    }
}
?>