<?php

class Translate
{
	public $translateLang = array();

    function __construct($param)
    {
    	$lang = $param['lang'];
    	$db = $GLOBALS['db'];

    	// translate from file
    	if(is_file("../sajt/lang/{$lang}.php")) {
    	    include("../sajt/lang/{$lang}.php");
            $this->translateLang = $translate['translate'][$lang];
    	}

    	// translate from db
    	$query = "
            SELECT `key`, `content`
            FROM `translate`

            LEFT JOIN `translate_text`
            USING(id)

            WHERE 1
            AND `lang` = '" . addslashes($lang) . "'
            AND `deleted` = '0'
        ";
    	$list = $db->getRows($query);

    	foreach($list as $row) {
    	    $key = htmlspecialchars(stripslashes($row['key']));
    	    $content = htmlspecialchars(stripslashes($row['content']));

    	    $this->translateLang[$key] = $content;
    	}
    }

    function _t($text)
    {
    	if( !empty($this->translateLang[$text]) ) {
    		$res = $this->translateLang[$text];
    	} else {
    		$res = $text;
    	}

    	return $res;
    }
}
?>