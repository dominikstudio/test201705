
<?php

class Html_Editor
{
    private $inc_dir;
	private $base_dir;

    function __construct()
    {
        $this->inc_dir = dirname(__FILE__);
		$this->base_dir = $GLOBALS['config']['base_dir'];
    }

    function editor($name, $dir = 'page', $text = '')
    {
        $html = file_get_contents($this->inc_dir . '/html_editor.html');
        $editor_img = $this->getEditorImg($dir);

        $html = str_replace('{editor_img}', $editor_img, $html);
        $html = str_replace('{name}', $name, $html);
        $html = str_replace('{text}', $text, $html);
        $html = str_replace('{user_dir}', $this->base_dir . DIR, $html);
        $html = str_replace('{base_dir}', $this->base_dir, $html);

        $html .= get_js('ajax/load');

        return $html;
    }

    function getEditorImg($dir) // with load form
    {
        $res = '';

        $dir = '' . $this->base_dir . 'files/' . DIR . '/img/' . $dir;
        $current_dir = $dir;

        $dir = './' . $dir;
        $path = '/' . $this->base_dir . $GLOBALS['config']['admin_path'] . '/ajax/file';

        if( is_dir($dir) )
        {
            $list = scandir($dir);
            natsort($list);

            $res .= '
                    <input name="file" type="file" id="load_file">
                    <input type="button" value="Завантажити файл" onclick="ajaxLoadFile(document.getElementById(\'image_list_{name}\'), \'' . $current_dir. '\', document.getElementById(\'load_file\'), \'' . $path . '/load_img\');">
                <br>';

            $res .= '<div id="image_list_{name}">';

            foreach($list as $file_name)
            {
                if($file_name == '.' || $file_name == '..') continue;

                if(!is_dir($dir . '/' . $file_name))
                {
                    $file_ext = strrchr($file_name,  ".");
                    $img_ext_array = array('.gif', '.GIF', '.jpg', '.JPG', '.png', '.PNG');

                    if(in_array($file_ext, $img_ext_array))
                        $img_src = '/' . $current_dir . '/' . $file_name;
                    else
                        continue;

                    $size = getimagesize($dir . '/' . $file_name);
                    $img_width  = ($size['0'] > 200) ? 200 : $size['0'];
                    $img_height = intval($size['1'] * ($img_width / $size['0']));

                    $img_id = md5($img_src);

                    $res .= '
                        <div style="height: 120px; width: 120px; overflow: hidden; text-align: left; float: left; padding: 10px;">
                        <img src="' . $img_src . '" height="100px" border="0" onclick="vkImageShowParam(\'img_param_' . $img_id . '\')">
                        <div id="img_param_' . $img_id . '" style="position: absolute; display: none; z-index: 4; background: #eee; border: 2px solid grey;">
                        Розміри<br>
                        <input id="img_param_' . $img_id . '_src" type="hidden" name="src" value="' . $img_src . '">
                        шир. <input id="img_param_' . $img_id . '_width" type="text" name="width" value="' . $img_width . '" disabled="true" style="width: 40px;">
                        вис. <input id="img_param_' . $img_id . '_height" type="text" name="height" value="' . $img_height . '" disabled="true" style="width: 40px;"><br>
                        Вирівнювання<br>
                        <select id="img_param_' . $img_id . '_align" name="align" style="float: left;">
                        <option value="left">Зліва
                        <option value="right">Справа
                        </select>
                        <div class="html-button" onclick="vkImageInsert(\'img_param_' . $img_id . '\');"><b><a href="javascript:void(0);">Вставити мал.</a></b></div>
                        </div>
                        </div>';
                }
            }

            $res .= '</div>';
        }

        return $res;
    }
}
?>