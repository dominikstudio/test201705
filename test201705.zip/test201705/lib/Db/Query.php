<?php

class Db_Query
{
    function setConnect()
    {
        $res = '';

        $db_connect = mysql_connect(DB_HOST, DB_USER, DB_PASS);

        mysql_query("set names utf8");
        mysql_query("set character_set_client='utf8'");
        mysql_query("set character_set_results='utf8'");
        mysql_query("set character_set_connection='utf8'");
        mysql_query("set character_set_database='utf8'");
        mysql_query("set collation_connection='utf8_unicode_ci'");

        mysql_select_db(DB_NAME, $db_connect);

        return $res;
    }

    function getOne($query)
    {
        $res = '';

        if($query)
		{
            $query = mysql_query($query);

            if($query)
			{
                list($res) = mysql_fetch_row($query);
            }
        }
        return $res;
    }

    function getOneRow($query)
    {
        $res = array();

        if($query)
		{
            $query = mysql_query($query);

            if($query)
			{
                $res = mysql_fetch_array($query);
            }
        }
        return $res;
    }

    function getRows($query)
    {
        $res = array();

        if($query)
		{
            $query = mysql_query($query);

            if($query)
			{
                while( $one_row = mysql_fetch_array($query) ) {
                    $res[] = $one_row;
               }
            }
        }
        return $res;
    }

    function insert($query)
    {
        $query = mysql_query($query);
        $res = mysql_insert_id();
        
        return $res;
    }

    function query($query)
    {
        $query = mysql_query($query);
        return $query;
    }
}
?>