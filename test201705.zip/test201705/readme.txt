
1. Please, put the folder 'test201705' in the root directory of the Apache (DocumentRoot in conf/httpd.conf)

2. sql for database - in file 'bd.sql' (in folder 'test201705')

3. In file 'test201705/app/common/config.php' on lines 7-10. 
need set own DB_NAME, DB_USER, DB_PASS

4. In your browser, open 'http://localhost/test201705/public_html/'
