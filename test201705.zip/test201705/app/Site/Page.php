<?php

class Page
{
    public $db;
    public $param;
    public $lang;

    private $page_template;
    private $page_title;
    private $page_content;

    function __construct($param)
    {
        $this->db = $GLOBALS['db'];
        $this->param = $param;
        $this->lang = $param['lang'];
		
		if(!empty($param['ajax']))
        {
		    require_once("../lib/Ajax/JsHttpRequest.php");
            $JsHttpRequest =& new JsHttpRequest("utf-8");
		}

        $this->getDynamic();
		$res = $this->getPage();

		$js = get_js('validate');
		$js .= get_js('block');
		$js .= get_js('ajax/load_event');

		$this->page_content = $res . $js;
    }

    function getDynamic()
    {
        $current_page = ucfirst(strtolower(htmlspecialchars($this->param['page_name'])));
        $file_name = dirname(__FILE__) . "/Page/{$current_page}.php";
        $class_name = "Page_{$current_page}";

        if( is_file($file_name) ) 
		{
            @include_once($file_name);

            if( class_exists($class_name) ) 
			{
                $page = new $class_name($this->db);
                $this->page_content = $page->getContent($this->param);
            }
        }
    }
	
	public function getContent()
	{
		return $this->page_content;
	}

    function getPage()
    {
		include_once('../app/block/block.php');

        $template = $this->getTemplate();

        if( empty($this->page_content) ) 
		{
            $this->page_title = 'Page under construction';
        }

        if( substr_count($template, '{base_dir}') ) 
            $template = str_replace('{base_dir}', $GLOBALS['config']['base_dir'], $template);

        if( substr_count($template, '{page_title}') )
            $template = str_replace('{page_title}', $this->page_title, $template);
		
		if( substr_count($template, '{page_content}') )
            $template = str_replace('{page_content}', $this->page_content, $template);
		
		if( substr_count($template, '{block_enter}') )
            $template = str_replace('{block_enter}', get_block_enter(), $template);

        return $template;
    }

    function getTemplate($template = 'page')
    {
        $res = '';

        $query = "
SELECT `content`
FROM `site`

WHERE 1
AND `type` = 'template'
AND `name` = '" . trim( addslashes($template) ) . "'
AND NOT `deleted`
        ";

        $res = $this->db->getOne($query);

        if( empty($res) )
        {
            if( is_file('../app/template/' . DIR . '/' . $template . '.html') )
            {
                $res = file_get_contents('../app/template/' . DIR . '/' . $template . '.html');
            }
            elseif( is_file('../app/template/' . $template . '.html') )
            {
                $res = file_get_contents('../app/template/' . $template . '.html');
            }
        }
        else
        {
        	$res = stripslashes($res);
        }

        return $res;
    }
}
?>