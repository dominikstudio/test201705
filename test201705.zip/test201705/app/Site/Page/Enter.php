<?php

class Page_Enter
{
    private $db;
    private $param;

    function __construct($db)
    {
        $this->db = $db;
    }
	
	function getContent($param)
    {
		$this->param = $param;
		
		if($param['ajax'])
			$this->getAjax();
	}

    function getAjax()
    {
		require_once("../lib/Ajax/JsHttpRequest.php");
        $JsHttpRequest =& new JsHttpRequest("utf-8");
		
    	$t = $GLOBALS['translate'];

    	$check = false;
    	$current_user_name = '';
    	$answer = '';

    	if( !empty($_REQUEST['mail'])  ) {

    		if( !empty($_REQUEST['password']) ) {

				if($this->checkUser()) {
					$check = true;
	                $answer = '';
				} else {
					$answer = '<span style="color: red;">' . $t->_t('Wrong password') . '</span>';
				}

    		} else {
    			$answer = '<span style="color: red;">' . $t->_t('Missing password') . '</span>';
    		}

    	} else {
    		$answer = '<span style="color: red;">' . $t->_t('Missing login') . '</span>';
    	}

        $GLOBALS['_RESULT'] = array(
            "check"        => $check,
            "answer"       => $answer
        );
        exit();
    }

    function checkUser()
    {
    	$res = false;

        $mail = ( isset($_REQUEST['mail']) && $_REQUEST['mail'] ) ? htmlspecialchars(addslashes($_REQUEST['mail'])) : '';
        $password = ( isset($_REQUEST['password']) && $_REQUEST['password'] ) ? htmlspecialchars(addslashes($_REQUEST['password'])) : '';

        if($mail && $password) {
            $query = "
SELECT `id`, `user`, `status`, `mail`
FROM `user_site`

WHERE 1
AND `mail` = '{$mail}'
AND `password` = MD5('{$password}')
AND `blocked` = '0'
AND `deleted` = '0'
            ";

            $row = $this->db->getOneRow($query);

            if( !empty($row) && is_array($row) && count($row) ) {

            	$id_db = ( !empty($row['id']) ) ? htmlspecialchars(stripslashes($row['id'])) : '';
            	$user_db = ( !empty($row['user']) ) ? htmlspecialchars(stripslashes($row['user'])) : '';
            	$mail_db = ( !empty($row['mail']) ) ? htmlspecialchars(stripslashes($row['mail'])) : '';
            	$status_db = ( !empty($row['status']) ) ? htmlspecialchars(stripslashes($row['status'])) : '';

            	if($mail == $mail_db) {
            		$_SESSION['current_user_id'] = $id_db;
            		$_SESSION['current_user'] = $mail_db;
            		$_SESSION['current_user_name'] = $user_db;
            		$_SESSION['current_user_status'] = $status_db;

            		$user_id = ( !empty($row['id']) ) ? htmlspecialchars(floor($row['id']) * 1) : '';

            		if($user_id) {
            			setcookie('userid', $user_id, time()+60*24*3600, '/');
            		}

            		$res = true;

            	} else {
            		$_SESSION['current_user'] = '';
            	}

            } else {
                $_SESSION['current_user'] = '';
            }

        } else {
            $_SESSION['current_user'] = '';
        }

        return $res;
    }
}
?>