<?php

class Page_Invitation
{
    private $db;
    private $param;

    function __construct($db)
    {
        $this->db = $db;
    }
	
	function getContent($param)
    {
		$this->param = $param;
		
		if($param['ajax'])
			$this->getAjax();
	}
	
	function getAjax()
    {
		require_once("../lib/Ajax/JsHttpRequest.php");
        $JsHttpRequest =& new JsHttpRequest("utf-8");
		
    	$t = $GLOBALS['translate'];
    	$res = '';

    	if( !empty($_REQUEST['mail']) ) 
		{
			$mail_web = htmlspecialchars($_REQUEST['mail']);

			$count_point = substr_count($mail_web, '.');
			$count_at = substr_count($mail_web, '@');

			if($count_at == 1 && $count_point >= 1) 
			{
				if( !$this->checkBusyMail($mail_web) ) 
				{
					$this->saveMail($mail_web);
					$this->sendMail();

					$res .= '<br><span style="color: #0af;">Invitation was <a href="' . $this->link . '">' . $t->_t('send') . '</a></span>';
				} 
				else 
				{
					$res = '<span style="color: red;">' . $t->_t('E-mail is busy') . '</span>';
				}
			} 
			else 
			{
				$res = '<span style="color: red;">' . $t->_t('Wrong E-mail') . '</span>';
			}
		} 
		else 
		{
			$res = '<span style="color: red;">' . $t->_t('Missing E-mail') . '</span>';
		}
				
        $GLOBALS['_RESULT']['answer'] = $res;
        exit();
    }
	
	function checkBusyMail($mail_web)
    {
    	$query = "
            SELECT `mail`
            FROM `user_site`
            WHERE 1
            AND `mail` = '" . addslashes($mail_web) . "'
        ";

        $row = $this->db->getOneRow($query);

        if( !empty($row) && is_array($row) && count($row) ) {
        	$res = true;
        } else {
        	$res = false;
        }

        return $res;
    }

    function saveMail($mail_web)
    {
    	$t = $GLOBALS['translate'];

    	$mail  = addslashes($mail_web);
    	$time = time();
    	$this->link = $GLOBALS['config']['web_my_site'] . 'confirm/' . $time . '/' . $mail;

    	$query = "INSERT INTO `user_site` SET
            `mail`    = '{$mail}',
            `time`    = '{$time}',
            `blocked` = '1'
        ";
        $this->db->query($query);
    }

    function sendMail()
    {
    	$t = $GLOBALS['translate'];

        // send mail
        $subject = 'Invitation';

        $message = '
' . $t->_t('Registration online from site') . ' ' . $GLOBALS['config']['web_my_site'] . '

' . $t->_t('You link') . ': ' . $this->link . ' ' ;

        $headers = 'From: ' . $GLOBALS['config']['mailfrom'] . "\r\n";
        $headers  .= 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

        mail($this->mail, $subject, $message, $headers);
    }
}
?>