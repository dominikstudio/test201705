<?php

include_once('../lib/Editor/HtmlEditor.php');
include_once('../lib/Calendar/HtmlCalendar.php');

class Page_Event
{
    public $db;
	private $base_dir;
	public $HtmlCalendar;
	public $HtmlEditor;

    function __construct($db)
    {
        $this->db = $db;
		$this->base_dir = $GLOBALS['config']['base_dir'];
    }

    function getContent($param)
    {
        $this->HtmlCalendar = new Html_Calendar();
		$this->HtmlEditor = new Html_Editor();
		
        $res = '';
		
		$user_data = $this->checkUser();
		
		if( !empty($user_data) ) 
		{			
			// check for user new
			if(!empty($_SESSION['new_registration']))
			{
				unset($_SESSION['new_registration']);
				$id = intval($user_data['id']);
				$mail = htmlspecialchars(stripslashes($event_data['mail']));
				$password = htmlspecialchars(stripslashes($event_data['pwd']));
				
				$res .= '<span>Registration was finished, your data  <br>ID: ' . $id . '<br>Login: ' . $mail . '<br> Password:' . $password . '</span><br><br>';
			}
			
			$param['1'] = ( !empty($param['1']) ) ? $param['1'] : 'calendar';

			if($param['1'] == 'calendar')
				$res .= $this->getEventCalendar($param);
			if($param['1'] == 'editcalendar')
				$res .= $this->getEditCalendar($param);
			elseif($param['1'] == 'view')
				$res .= $this->getEvent($param, $user_data);
		    elseif($param['1'] == 'add')
				$res .= $this->addEvent($user_data);
		    elseif($param['1'] == 'edit')
				$res .= $this->editEvent($param, $user_data);
		    elseif($param['1'] == 'delete')
				$this->deleteEvent($param, $user_data);
		}
		else
		{
			$res = 'Please, log in, for view of this page';
		}
		
		if(!empty($param['ajax']))
        {
            $GLOBALS['_RESULT']['value'] = $res;
            exit();
		}

        return $res;
    }
	
	function getEventCalendar($param)
    {
		$res = '';
		
		if(!empty($param['ajax']))
        {
            $param['date'] = (!empty($_REQUEST['date'])) ? $_REQUEST['date'] : date("Ymd");
		}
		
		$res .= '<a href="/' . $this->base_dir . 'event/add/">add event</a><br><br>';

        $res .= $this->HtmlCalendar->calendar($param);

        return $res;
    }
	
	function getEditCalendar($param)
    {
		if(!empty($param['ajax']))
        {
            $param['date'] = $_REQUEST['date'];
            $param['name'] = $_REQUEST['name'];
            $param['id'] = $_REQUEST['id'];
		}

        $res = $this->HtmlCalendar->calendarEdit($param, $param['date'], $param['name'], $param['id']);

        return $res;
    }

	function getEvent($param, $user_data)
    {
        $res = '';
		
        $res .= '<a href="javascript:ajaxLoadEvent(document.getElementById(\'page_content\'), \'/'.$this->base_dir.'ajax/event/\', \''.date("Ymd").'\');">show calendar of events</a><br><br>';

        $id = ( !empty($param['2']) ) ? intval($param['2']) : 0;

        if($id > 0)
        {
            $query = "
SELECT `name`, `date`, `date_end`, e.`time`, e.`time_end`, `text`, `user_id`, `user`, e.`status`, `color`
FROM `event` e

LEFT JOIN `user_site` u
ON(e.user_id = u.id)

WHERE 1
AND e.`id` = '{$id}'
AND e.`show` = '1'
AND e.`deleted` = '0'
LIMIT 1
            ";
			
			$event_data = $this->db->getOneRow($query);
        }

        if(!empty($event_data))
		{
			$date = date("Ymd", strtotime($event_data['date']));
			$from = date("d-m-Y H:i", strtotime($date . $event_data['time']));
			
			$date_end = date("Ymd", strtotime($event_data['date_end']));
			$to = date("d-m-Y H:i", strtotime($date_end . $event_data['time_end']));
			
			$status_list = $this->getListStatus();
			$status = $status_list[$event_data['status']];
			
			$color = '<div style="background: ' . htmlspecialchars(stripslashes($event_data['color'])) . '; width: 20px; height: 20px;">&nbsp;</div>';
			
			$res .= '<h3>Event ID ' . $id . '</h3>';
			
			$res .= '<table width="500px">';
			$res .= '<tr><td width="100px">Name</td><td>' . htmlspecialchars(stripslashes($event_data['name'])) . '</td></tr>';
			$res .= '<tr><td width="100px">From</td><td>' . $from . '</td></tr>';
			$res .= '<tr><td width="100px">To</td><td>' . $to . '</td></tr>';
			$res .= '<tr><td width="100px">Description</td><td>' . stripslashes($event_data['text']) . '</td></tr>';
			$res .= '<tr><td width="100px">Author</td><td>' . htmlspecialchars(stripslashes($event_data['user'])) . '</td></tr>';
			$res .= '<tr><td width="100px">Status</td><td>' . $status . '</td></tr>';
			$res .= '<tr><td width="100px">Color</td><td>' . $color . '</td></tr>';
			$res .= '</table>';
			
			// check user
			if($event_data['user_id'] == $user_data['id'] || $user_data['status'] == 'admin')
			{
				// can edit & delete
				$res .= '<a href="/' . $this->base_dir . 'event/edit/' . $id . '">edit</a> &nbsp;';
				$res .= '<a href="/' . $this->base_dir . 'event/delete/' . $id . '" onclick="return confirm(\'Delete this event ?\');">delete</a><br><br>';
			}
		}
		else
		{
			$res .= 'Empty event';
		}

        return $res;
    }
	
	function addEvent($user_data)
    {
        $res = '';
		
		$res .= '<a href="javascript:ajaxLoadEvent(document.getElementById(\'page_content\'), \'/'.$this->base_dir.'ajax/event/\', \''.date("Ymd").'\');">show calendar of events</a><br><br>';

        $res .= '<h3>Add Event</h3>';

        if( !empty($_POST['save']) && $_POST['save'] == 'add')
        {
            $date = date("Y-m-d", strtotime($_POST['date']));
            $date_end = date("Y-m-d", strtotime($_POST['date_end']));

            $query = "
                INSERT INTO `event` SET
                    `date`     = '" . $date . "',
                    `date_end` = '" . $date_end . "',
                    `time`     = '" . trim( addslashes($_POST['time']) ) . "',
                    `time_end` = '" . trim( addslashes($_POST['time_end']) ) . "',
                    `name`     = '" . trim( addslashes($_POST['name']) ) . "',
                    `color`    = '" . trim( addslashes($_POST['color']) ) . "',
                    `status`   = '" . trim( addslashes($_POST['status']) ) . "',
                    `user_id`  = '" . intval($user_data['id']) . "',
                    `text`     = '" . trim( addslashes($_POST['text']) ) . "'
            ";
            $id = $this->db->insert($query);

            header('Location: /' . $this->base_dir . 'event/view/' . $id);
        }
        else
        {
			$time_list = $this->getListTime();
			$times = '';
			
			foreach($time_list as $time_key => $time)
            {
                $times .= '<option value="' . $time_key . '" >' . $time;
            }
			
			$status_list = $this->getListStatus();
			$statuses =  '';
			
			foreach($status_list as $status_key => $status)
            {
                $statuses .= '<option value="' . $status_key . '" >' . $status;
            }

            $res .= '
                <br>
                <form enctype="multipart/form-data" method="post">
                <input type="hidden" name="save" value="add">

                <fieldset>
                    <legend>Event data:</legend>
                    Name <br>
                    <input name="name" type="text" size="100"><br><br>
					Date begin <br>
					' . $this->HtmlCalendar->calendarEdit(null, date('d.m.Y'), 'date', '001') . '
					Time begin <br>
					<select name="time">
					' . $times . '
					</select><br><br>
					Date end <br>
					' . $this->HtmlCalendar->calendarEdit(null, date('d.m.Y'),'date_end', '002') . '
					Time end <br>
					<select name="time_end">
					' . $times . '
					</select><br><br>
					
					Status <br>
					<select name="status">
					' . $statuses . '
					</select><br><br>
					
					
					<div id="event_color_current" class="color-button" style="background: #aaa; width: 50px; height: 20px;" onClick="vkColor(\'event_colours\');">&nbsp;</div>Color
					<div id="event_colours" style="display: none; position: absolute;"></div>
					<input id="event_color" type="hidden" name="color" value="#aaa">
					<br><br>

					Description
            ';

            $res .= $this->HtmlEditor->editor('text', $this->current_dir, '');
            //$res .= '<i>Note: insert img via button "Image"</i><br><br>';
            $res .= '</fieldset>';
            
            $res .= '<br><input type="button" value="Save" onclick="editorSubmit(this.form);"></form>';
        }

        return $res;
    }
	
	function editEvent($param, $user_data)
    {
		$id = ( !empty($param['2']) ) ? intval($param['2']) : 0;

        if($id > 0)
        {
            $query = "
SELECT `id`, `name`, `date`, `date_end`, `time`, `time_end`, `text`, `user_id`, `status`, `color`
FROM `event`

WHERE 1
AND `id` = '{$id}'
AND `show` = '1'
AND `deleted` = '0'
LIMIT 1
            ";
			
			$event_data = $this->db->getOneRow($query);
        }
		
		// check user
		if(!empty($event_data) && ($event_data['user_id'] == $user_data['id'] || $user_data['status'] == 'admin') )
		{
			// can edit
		}
		else
		{
			header('Location: /' . $this->base_dir . 'event/');
		}
		
        $res = '';
		
		$res .= '<a href="javascript:ajaxLoadEvent(document.getElementById(\'page_content\'), \'/'.$this->base_dir.'ajax/event/\', \''.date("Ymd").'\');">show calendar of events</a><br><br>';

        $res .= '<h3>Edit Event ID '.$id.'</h3>';

        if( !empty($_POST['save']) && $_POST['save'] == 'edit')
        {
            $date = date("Y-m-d", strtotime($_POST['date']));
            $date_end = date("Y-m-d", strtotime($_POST['date_end']));

            $query = "
                UPDATE `event` SET
                    `date`     = '" . $date . "',
                    `date_end` = '" . $date_end . "',
                    `time`     = '" . trim( addslashes($_POST['time']) ) . "',
                    `time_end` = '" . trim( addslashes($_POST['time_end']) ) . "',
                    `name`     = '" . trim( addslashes($_POST['name']) ) . "',
                    `color`    = '" . trim( addslashes($_POST['color']) ) . "',
                    `status`   = '" . trim( addslashes($_POST['status']) ) . "',
                    `user_id`  = '" . intval($event_data['user_id']) . "',
                    `text`     = '" . trim( addslashes($_POST['text']) ) . "'
				WHERE `id` = '" . $id . "'
            ";
            $this->db->query($query);

            header('Location: /' . $this->base_dir . 'event/view/' . $id);
        }
        else
        {
			$time_list = $this->getListTime();
			$times = '';
			$times_end = '';
			
			foreach($time_list as $time_key => $time)
            {
				if($time_key == $event_data['time'])
					$times .= '<option value="' . $time_key . '" selected="selected" >' . $time;
				else
                    $times .= '<option value="' . $time_key . '" >' . $time;
            }
			
			foreach($time_list as $time_key => $time)
            {
				if($time_key == $event_data['time_end'])
					$times_end .= '<option value="' . $time_key . '" selected="selected" >' . $time;
				else
                    $times_end .= '<option value="' . $time_key . '" >' . $time;
            }
			
			
			$status_list = $this->getListStatus();
			$statuses =  '';
			
			foreach($status_list as $status_key => $status)
            {
				if($status_key == $event_data['status'])
				    $statuses .= '<option value="' . $status_key . '" selected="selected" >' . $status;
				else
                    $statuses .= '<option value="' . $status_key . '" >' . $status;
            }

            $res .= '
                <br>
                <form enctype="multipart/form-data" method="post">
                <input type="hidden" name="save" value="edit">

                <fieldset>
                    <legend>Event data:</legend>
                    Name <br>
                    <input name="name" value="' . htmlspecialchars(stripslashes($event_data['name'])) . '" type="text" size="100"><br><br>
					Date begin <br>
					' . $this->HtmlCalendar->calendarEdit(null, date('d.m.Y', strtotime($event_data['date'])), 'date', '001') . '
					Time begin <br>
					<select name="time">
					' . $times . '
					</select><br><br>
					Date end <br>
					' . $this->HtmlCalendar->calendarEdit(null, date('d.m.Y', strtotime($event_data['date_end'])),'date_end', '002') . '
					Time end <br>
					<select name="time_end">
					' . $times_end . '
					</select><br><br>
					
					Status <br>
					<select name="status">
					' . $statuses . '
					</select><br><br>
					
					
					<div id="event_color_current" class="color-button" style="background: ' . htmlspecialchars(stripslashes($event_data['color'])) . '; width: 50px; height: 20px;" onClick="vkColor(\'event_colours\');">&nbsp;</div>Color
					<div id="event_colours" style="display: none; position: absolute;"></div>
					<input id="event_color" type="hidden" name="color" value="' . htmlspecialchars(stripslashes($event_data['color'])) . '">
					<br><br>

					Description
            ';

            $res .= $this->HtmlEditor->editor('text', $this->current_dir, stripslashes($event_data['text']));
            //$res .= '<i>Note: insert img via button "Image"</i><br><br>';
            $res .= '</fieldset>';
            
            $res .= '<br><input type="button" value="Save" onclick="editorSubmit(this.form);"></form>';
        }

        return $res;
    }
	
	function deleteEvent($param, $user_data)
	{
		$id = ( !empty($param['2']) ) ? intval($param['2']) : 0;

        if($id > 0)
        {
            $query = "
SELECT `id`, `user_id`
FROM `event`

WHERE 1
AND `id` = '{$id}'
AND `show` = '1'
AND `deleted` = '0'
LIMIT 1
            ";
			
			$event_data = $this->db->getOneRow($query);
        }
		
		// check user
		if(!empty($event_data) && ($event_data['user_id'] == $user_data['id'] || $user_data['status'] == 'admin') )
		{
			// can delete
            $query = "
                UPDATE `event` SET
                    `show`    = '0',
                    `deleted` = '1'
				WHERE `id` = '" . $id . "'
            ";
            $this->db->query($query);
		}
		
		header('Location: /' . $this->base_dir . 'event/');
	}

    function getMonthTitle($month)
    {
        $month_title = array(1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April', 5 => 'May', 6 => 'June', 7 => 'Jule', 8 => 'August', 9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December' );

        $res = $month_title[$month];

        return $res;
    }
	
	function getListTime()
	{
		$times = array(
		    '0800' => '8-00',
		    '0900' => '9-00',
		    '1000' => '10-00',
		    '1100' => '11-00',
		    '1200' => '12-00',
		    '1300' => '13-00',
		    '1400' => '14-00',
		    '1500' => '15-00',
		    '1600' => '16-00',
		    '1700' => '17-00',
		    '1800' => '18-00',
		    '1900' => '19-00',
		    '2000' => '20-00'
		);
		
		return $times;
	}
	
	function getListStatus()
	{
		$status = array(
		    'new'      => 'New',
		    'progress' => 'In progress',
		    'done'     => 'Done'
		);
		
		return $status;
	}
	
	function checkUser()
	{
		$id = ( !empty($_SESSION['current_user_id']) ) ? intval($_SESSION['current_user_id']) : '';

        $query = "
                SELECT `id`, `status`, `mail`, `pwd`
                FROM `user_site`
                WHERE `id` = '" . $id . "'
                AND `blocked` = '0'
                AND `deleted` = '0'
        ";

        $row = $this->db->getOneRow($query);
		
		return $row;
	}
}
?>