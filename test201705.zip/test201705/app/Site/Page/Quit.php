<?php

class Page_Quit
{
    private $db;
    private $param;

    function __construct($db)
    {
        $this->db = $db;
    }
	
	function getContent($param)
    {
		$this->param = $param;
		
		if($param['ajax'])
			$this->getAjax();
	}

    function getAjax()
    {
		require_once("../lib/Ajax/JsHttpRequest.php");
        $JsHttpRequest =& new JsHttpRequest("utf-8");
		
    	if( !empty($_REQUEST['quit'])  ) {
    		unset($_SESSION['current_user']);
    		unset($_SESSION['current_user_name']);
    		unset($_SESSION['current_user_id']);
    		unset($_SESSION['current_user_status']);
    		setcookie('userid', '', time()-10, '/');
    		$quit = true;
    	} else {
    		$quit = false;
    	}

        $GLOBALS['_RESULT'] = array("quit" => $quit);
        exit();
    }
}
?>