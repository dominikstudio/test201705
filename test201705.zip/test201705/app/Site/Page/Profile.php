<?php

class Ajax_Profile
{
    private $db;
    private $param;
    private $inc_dir;

    function __construct($param)
    {
        $this->db = $GLOBALS['db'];
        $this->param = $param;
        $this->inc_dir = dirname(__FILE__);

        $this->init();
    }

    function init()
    {
        $res = '';

    	if( isset($_REQUEST['catalog']) && trim($_REQUEST['catalog']) && !empty($_SESSION['current_user']) ) {

    	    // check for admin  status
    	    $session_id = $_SESSION['current_user_id'];

    		$param_id = (!empty($this->param['3'])) ? floor($this->param['3'] * 1) : $session_id;
            $param_id = ($param_id == 0) ? $session_id : $param_id;
            $param_id = ($_SESSION['current_user_status'] == 'admin') ? $param_id : $session_id;

            $this->param['3'] = $param_id;

    	    $current_action = ucfirst(strtolower(htmlspecialchars($this->param['1'])));
            $file_name = $this->inc_dir . "/../Page/{$current_action}.php";
            $class_name = "Page_{$current_action}";

            // set param for ajax
            $param_ajax = array();
            $param_ajax['0'] = $this->param['1']; //page
            $param_ajax['1'] = $this->param['2'];  //view
            $param_ajax['2'] = $this->param['3'];  //id
            $param_ajax['3'] = $this->param['4'];  //action
            $param_ajax['ajax'] = '1';

            if( is_file($file_name) ) {
                @include_once($file_name);

                if( class_exists($class_name) ) {
                    $ajax = new $class_name($this->db);

                    if( !empty($this->param['4']) && $this->param['4'] == 'load') { // load file
            	        $ajax->_load($param_ajax);
            	    }

                    $res = $ajax->editFoto($this->param['3']);
                }
            }

            $GLOBALS['_RESULT'] = array("value" => $res);
            exit();
    	}
    }
}
?>