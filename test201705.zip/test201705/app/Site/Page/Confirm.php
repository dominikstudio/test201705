<?php

class Page_Confirm
{
    public $db;
    private $base_dir;
	private $inc_dir;
	private $mail;

    function __construct($db)
    {
        $this->db = $db;
		$this->base_dir = $GLOBALS['config']['base_dir'];
		$this->inc_dir = dirname(__FILE__);
    }

    function getContent($param)
    {
		if(!empty($param['ajax']))
			$this->getAjax();

    	$user_id = $this->checkCode($param);

    	if( !empty($user_id) ) 
		{
            $res = $this->getForm($user_id);
    	} 
		else 
		{
    		header('Location: /' . $this->base_dir );
    		exit;
    	}

    	return $res;
    }
	
	function checkCode($param)
    {
		$res = '';
		
    	if( !empty($param['1']) && !empty($param['2']) ) 
		{
    		$time = $param['1'];
    		$mail = $param['2'];

    		$query = "
	            SELECT `id`
	            FROM `user_site`
	            WHERE 1
	            AND `mail` = '" . addslashes($mail) . "'
	            AND `time` = '" . addslashes($time) . "'
	        ";

            $user_id = $this->db->getOne($query);

            if( !empty($user_id) ) 
            	$res = intval($user_id);
    	} 

    	return $res;
    }
	
	function getForm($user_id)
    {
    	$t = $GLOBALS['translate'];

    	$res = '';
    	$res .= '
    	    <h2>
                ' . $t->_t('Registration') . '
            </h2><br><br>';

    	// insert ajax
    	$res .= '
    	    <script language="JavaScript">
    	    function confirm_local() {
    	        document.getElementById("confirm_answer").innerHTML = "' . $t->_t('Load') . ' ...";

			    JsHttpRequest.query(
			        "/' . $this->base_dir . 'ajax/confirm",
			        {
			            \'user_id\'  : document.getElementById("confirm_user_id").value,
			            \'name\'     : document.getElementById("confirm_name").value
			        },
			        function(result) {
			            if (result) {
							if(result["reload"])
							    window.location.href = result["reload"];
							else							
			                    document.getElementById("confirm_answer").innerHTML = result["answer"];
			            }
			        },
			        false
			    );
			}
    	    </script>
    	';

		// form
    	$res .= '
	    	<form enctype="multipart/form-data" id="confirm_form" name="confirm_form" action="" method="post" onsubmit="return false;">
	    	    <div id="confirm_answer" style="display: block; height: 30px;"></div>
	    	    ' . $t->_t('Name') . '<br>
				<input id="confirm_name" type="text" name="name" autocomplete="off"><br><br>
	    	    <input id="confirm_user_id" type="hidden" name="user_id" value="' . $user_id . '">
	    	    <input type="button" value="' . $t->_t('Send') . '" style="width: 90px;" onclick="confirm_local();">
	    	</form>
	    ';

    	return $res;
    }
	
	// ajax request
	function getAjax()
    {
		require_once("../lib/Ajax/JsHttpRequest.php");
        $JsHttpRequest =& new JsHttpRequest("utf-8");
		
    	$t = $GLOBALS['translate'];

    	if( !empty($_REQUEST['name']) ) 
		{
			if($this->checkId()) 
			{
				$user_id = intval($_REQUEST['user_id']);

				$this->sendMail($user_id);
				setcookie('userid', $user_id, time()+60*24*3600, '/');
				$_SESSION['new_registration'] = true;
				
				$GLOBALS['_RESULT']['reload'] = $GLOBALS['config']['web_my_site'] ;
			}
			else 
			{
				$res = '<span style="color: red;">' . $t->_t('Wrong ID') . '</span>';
			}
    	}
		else 
		{
    		$res = '<span style="color: red;">' . $t->_t('Missing Name') . '</span>';
    	}

        $GLOBALS['_RESULT']['answer'] = $res;
        exit();
    }
	
	function checkId()
    {
    	$query = "
            SELECT `mail`
            FROM `user_site`
            WHERE 1
            AND `id` = '" . intval($_REQUEST['user_id']) . "'
        ";

        $row = $this->db->getOneRow($query);

        if( !empty($row) && is_array($row) && count($row) ) {

        	if( !empty($row['mail']) ) {
        		$this->mail = $row['mail'];
        		$res = true;
        	} else {
        		$res = false;
        	}
        } else {
        	$res = false;
        }

        return $res;
    }
	
	function sendMail($user_id)
    {
    	$t = $GLOBALS['translate'];

    	$name      = ( !empty($_REQUEST['name']) )  ? addslashes($_REQUEST['name']) : '';
    	$password  = substr(md5(time()), 0, 8);

    	$query = "
                UPDATE `user_site` SET
                    `user` = '" . $name . "',
                    `password` = '" . md5($password) . "',
                    `pwd` = '" . $password . "',
                    `time` = '" . date('Y-m-j') . "',
                    `blocked` = '0'
					
                WHERE `id` = '" . $user_id . "'
            ";
        $this->db->query($query);

        // send mail
        $subject = 'Registration completed';

        $message = '
' . $t->_t('Registration online') . ' ' . $GLOBALS['config']['web_my_site'] . ' ' . $t->_t('completed') . '.
' . $t->_t('Your data') . ':

' . $t->_t('ID') . ': ' . $user_id . '
' . $t->_t('Login') . ': ' . $this->mail . '
' . $t->_t('Password') . ': ' . $password . ' ' ;

        $headers = 'From: ' . $GLOBALS['config']['mailfrom'] . "\r\n";
        $headers  .= 'MIME-Version: 1.0' . "\r\n";
        $headers .= 'Content-type: text/html; charset=utf-8' . "\r\n";

        mail($this->mail, $subject, $message, $headers);
    }

}
?>