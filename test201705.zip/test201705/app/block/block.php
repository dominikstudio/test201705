<?php

function get_block_enter()
    {
    	$t = $GLOBALS['translate'];
		$base_dir = $GLOBALS['config']['base_dir'];
    	$res = '';

    	if( !empty($_SESSION['current_user']) )
    	{
    	    setcookie('userid', $_SESSION['current_user_id'], time()+30*24*3600, '/');

    		$res .= '<div style="font: italic bold 16px Bookman old style; line-height: 24px;">' . $t->_t('User') . '</div>';

    		$res .= '<div style="font: bold 14px Bookman old style; line-height: 24px;">' . $_SESSION['current_user_name'] . '</div>';

    		$res .= '
        	        <a href="#" onclick="quit_local()">
        	            <div style="font: bold 14px Bookman old style; color: red; line-height: 24px; float: left;">
        	                ' . $t->_t('Log out') . '
        	            </div>
        	        </a>
        	';

        	// insert ajax
        	$res .= '
        	    <script language="JavaScript">
        	    function quit_local() 
				{
    			    JsHttpRequest.query(
    			        "/' . $base_dir . 'ajax/quit",
    			        {
    			            \'quit\' : true
    			        },
    			        function(result) {
    			            if (result) {
    			                if(result["quit"]) {
    			                    window.location.reload();
    			                }
    			            }
    			        },
    			        false
    			    );
    			}
        	    </script>
        	';
			
			// invite (only admin)
			if($_SESSION['current_user_status'] == 'admin')
			{
				$res .= '
					<form action="" method="post" onsubmit="return false;">
						<br><br><div id="invite_answer"></div>
						' . $t->_t('Invitation for E-mail') . ': <br>
						<input id="invite_mail" type="text" value="" maxlength="50" name="mail" autocomplete="off"><br>

						<input type="button" value="' . $t->_t('Send') . '" style="text-align: left; border: 0px; background: transparent; text-decoration: underline; font-weight: bold;" onclick="send_invite_local();">
						&nbsp;&nbsp;&nbsp;
						
					</form>
				';
				
				// insert ajax
        	$res .= '
        	    <script language="JavaScript">
        	    function send_invite_local() 
				{
    			    JsHttpRequest.query(
    			        "/' . $base_dir . 'ajax/invitation",
    			        {
    			            \'mail\'     : document.getElementById("invite_mail").value,
    			        },
    			        function(result) {
    			            if (result) {
    			                document.getElementById("invite_answer").innerHTML = result["answer"];
    			            }
    			        },
    			        false
    			    );
    			}
        	    </script>
        	';
			}
    	}
    	else
    	{
        	$res .= '
                <form action="" method="post" onsubmit="return false;">
                    <div id="enter_answer"></div>
                    ' . $t->_t('Login') . ': <br>
                    <input id="enter_mail" type="text" value="" maxlength="50" name="mail" autocomplete="off"><br>
                    ' . $t->_t('Password') . ': <br>
                    <input id="enter_password" type="password" maxlength="50" name="password" autocomplete="off"><br><br>

                    <input type="button" value="' . $t->_t('Enter') . '" style="text-align: left; border: 0px; background: transparent; text-decoration: underline; font-weight: bold;" onclick="enter_local();">
                    &nbsp;&nbsp;&nbsp;
                    
                </form>
        	';

        	// insert ajax
        	$res .= '
        	    <script language="JavaScript">
        	    function enter_local() 
				{
    			    JsHttpRequest.query(
    			        "/' . $base_dir . 'ajax/enter",
    			        {
    			            \'mail\'     : document.getElementById("enter_mail").value,
    			            \'password\' : document.getElementById("enter_password").value
    			        },
    			        function(result) {
    			            if (result) {
    			                if(result["check"]) {
    			                    window.location.reload();
    			                } else {
    			                    document.getElementById("enter_answer").innerHTML = result["answer"];
    			                }
    			            }
    			        },
    			        false
    			    );
    			}
        	    </script>
        	';
    	}

    	return $res;
    }
?>