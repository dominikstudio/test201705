<?php

function get_js($name)
{
    $res = '';
    $name_id = md5($name);

    if( !isset($GLOBALS['js'][$name_id]) )
    {
        $GLOBALS['js'][$name_id] = $name;

        $res = '<script src="/' . $GLOBALS['config']['base_dir'] . 'txt/js/' . $name . '.js"></script>
        ';
    }

    return $res;
}

function get_action_image($action)
{
    $res = '';

    if(trim($action) && is_file('./files/img/' . $action))
    {
        $res = '<img src="/files/img/' . $action . '" border="0">';
    }

    return $res;
}

?>