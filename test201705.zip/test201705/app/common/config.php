<?php

// dir for site
define('DIR', 'site_test');

// db
define('DB_HOST', 'localhost');
define('DB_NAME', 'vasilij_phptest');
define('DB_USER', 'vasilij_phptest');
define('DB_PASS', 'vasilij_phptest');

// default
$GLOBALS['config']['base_dir'] = 'test201705/public_html/';
$GLOBALS['config']['lang_default'] = 'cz';
$GLOBALS['config']['page_default'] = 'event';
$GLOBALS['config']['separator_level'] = '.';
$GLOBALS['config']['page_suffix'] = '.html';
$GLOBALS['config']['mailto'] = 'b_dominik@meta.ua';
$GLOBALS['config']['mailfrom'] = 'b_dominik@meta.ua';
$GLOBALS['config']['web_my_site'] = 'http://localhost/' . $GLOBALS['config']['base_dir'];
$GLOBALS['config']['web_title'] = 'Sajt Test';

// from db
function get_config_data($db)
{
    $query = "
SELECT `name`, `content`
FROM `site`

WHERE 1
AND `type` = 'config'
AND NOT `deleted`
    ";

    $list = $db->getRows($query);

    if(!empty($list))
    {
        foreach($list as $row)
        {
            $name = $row['name'];
            $value = $row['content'];

            if( isset($GLOBALS['config'][$name]) && !empty($value) )
            {
                $GLOBALS['config'][$name] = htmlspecialchars(stripslashes($value));
            }
        }
    }
}

?>