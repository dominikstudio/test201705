<?php

function get_param($db)
{
    $param = htmlspecialchars($_SERVER['REQUEST_URI']);

    if($pos = strrpos($param, '?') )
        $param = substr($param, 0, $pos);
	
    if(!empty($GLOBALS['config']['base_dir']))
	    $param = str_replace($GLOBALS['config']['base_dir'], '', $param);

    $param_array = explode('/', $param);
    $param = array();

    foreach($param_array as $value)
    {
        if( trim($value) )
            $param[] = htmlspecialchars($value);
    }

    $lang_array = get_lang($db);

    if( isset($param['0']) && in_array($param['0'], $lang_array) ) 
	{
        $param['lang'] = $param['0'];
        array_shift($param);
    } 
	else 
	{
        $param['lang'] = $GLOBALS['config']['lang_default'];
    }
	
	// check for ajax request
	if( isset($param['0']) && $param['0'] == 'ajax' ) 
	{
        $param['ajax'] = true;
        array_shift($param);
    }

    // get default value with param
    if( !isset($param['0']) )
	{
        $GLOBALS['config']['page_default'] = str_replace('::', '/', $GLOBALS['config']['page_default']);
        $param_array = explode('/', $GLOBALS['config']['page_default']);
        $param = array();
        $param['lang'] = $GLOBALS['config']['lang_default'];

        foreach($param_array as $value)
        {
            if( trim($value) ) 
				$param[] = htmlspecialchars($value);
        }
    }

    $suffix_len = strlen($GLOBALS['config']['page_suffix']);

    if(substr($param['0'], -$suffix_len) == $GLOBALS['config']['page_suffix'])
	{
        $param['0'] = substr($param['0'], 0, -$suffix_len);
    }

    $param['page_name'] = $param['0'];

    $param['lang'] = htmlspecialchars(addslashes($param['lang']));
    $param['page_name'] = htmlspecialchars(addslashes($param['page_name']));

    return $param;
}

function get_lang($db)
{
    $lang_array = array();

    $query = "
SELECT `lang`
FROM `lang`
WHERE 1
AND NOT `deleted`
        ";

        $list = $db->getRows($query);

        if( is_array($list) && count($list) ) 
		{
            foreach($list as $row) 
			{
                $lang_array[] = htmlspecialchars($row['lang']);
            }
        }
		else 
		{
            $lang_array[] = $GLOBALS['config']['lang_default'];
        }

    return $lang_array;
}

function get_lang_title($db)
{
    $lang_array = array();

    $query = "
SELECT `lang`, `title`
FROM `lang`
WHERE 1
AND `show` = '1'
AND NOT `deleted`
    ";

    $list = $db->getRows($query);

    foreach($list as $row) 
	{
        $lang = htmlspecialchars($row['lang']);
        $title = htmlspecialchars($row['title']);

        $lang_array[$lang] = $title;
    }

    if( count($lang_array) == 0 ) 
	{
        $lang_array[$GLOBALS['config']['lang_default']] = 'українська';
    }

    return $lang_array;
}

function get_pages($db)
{
    $res = array();

    $query = "
        SELECT `page_name`
        FROM `page`
        WHERE 1
        AND `show` = '1'
        AND NOT `deleted`
    ";

    $list = $db->getRows($query);

    if( is_array($list) && count($list) ) 
	{
        foreach($list as $row) 
		{
            $res[] = htmlspecialchars($row['page_name']);
        }
    } 
	else 
	{
        $res[] = $GLOBALS['config']['page_default'];
    }

    return $res;
}
?>