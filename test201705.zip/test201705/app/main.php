<?php

    ini_set("display_errors", 1); // only for test

    header('Content-Type: text/html; charset="utf-8"');
    include(dirname(__FILE__) . '/common/config.php');
    require_once('../lib/Db/Query.php');

try {

    ob_start();
    session_start();

    $db = new Db_Query();
    $db->setConnect();
    $GLOBALS['db'] = $db;

    checkSessionCookie($db);

    include(dirname(__FILE__) . '/common/param.php');
    include(dirname(__FILE__) . '/common/common.php');
    get_config_data($db);
    $param = get_param($db);

    require_once('../lib/Translate/Translate.php');
    $GLOBALS['translate'] = new Translate($param);

    if( !empty($param['page_name']) )
    {
        $file_name = dirname(__FILE__) . "/Site/Page.php";
        $class_name = "Page";

        if( is_file($file_name) )
        {
            include_once($file_name);
			
            if( class_exists($class_name) )
            {
                $page = new $class_name($param);
				$res  = $page->getContent();
            }
        }
    }

    ob_get_clean();
    echo $res;

} catch (Exception $e) {
    exit('Сторінка не доступна');
}

    function checkSessionCookie($db)
    {
    	if( empty($_SESSION['current_user']) )
    	{
    		if( !empty($_COOKIE['userid']) )
    		{
    			$user_id = floor($_COOKIE['userid'] * 1);

    			$query = "
SELECT `id`, `user`, `status`, `mail`
FROM `user_site`

WHERE 1
AND `id` = '{$user_id}'
AND `blocked` = '0'
AND `deleted` = '0'
                ";

                $row = $db->getOneRow($query);

                if( !empty($row) && is_array($row) )
                {
	            	$id_db   = ( !empty($row['id']) ) ? intval($row['id']) : '';
                    $name_db = ( !empty($row['user']) ) ? htmlspecialchars(stripslashes($row['user'])) : '';
	            	$mail_db = ( !empty($row['mail']) ) ? htmlspecialchars(stripslashes($row['mail'])) : '';
	            	$status_db = ( !empty($row['status']) ) ? htmlspecialchars(stripslashes($row['status'])) : '';

	            	$_SESSION['current_user_id'] = $id_db;
            		$_SESSION['current_user'] = $mail_db;
            		$_SESSION['current_user_name'] = $name_db;
            		$_SESSION['current_user_status'] = $status_db;

            		setcookie('userid', $id_db, time()+60*24*3600, '/');
                }
    		}
    	}
    }
?>