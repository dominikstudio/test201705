<?php
    $translate['translate']['cz'] = array(
    );
?>